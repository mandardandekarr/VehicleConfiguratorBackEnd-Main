package com.example.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dtos.SubCompPrice;
import com.example.services.AlternateComponentService;

@RestController
public class AlternateComponentController {

	@Autowired
	AlternateComponentService alt_mgr;

	@GetMapping("api/defcompname/{model_id}")
	public List<SubCompPrice> getDefaultCompname(@PathVariable int model_id) {
		return alt_mgr.getDefaultCompname(model_id);
	}
	@GetMapping("api/compname/{model_id}")
	List<String> getCompname( int model_id)
	{
		return alt_mgr.getCompname(model_id);
	}
	// standard

	@GetMapping("api/seatbelt/{model_id}")
	public List<SubCompPrice> getConfigurableSeatBelt(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableSeatBelt(model_id);
	}

	@GetMapping("api/airbag/{model_id}")
	public List<SubCompPrice> getConfigurableAirbag(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableAirbag(model_id);
	}

	@GetMapping("api/gps/{model_id}")
	public List<SubCompPrice> getConfigurableGPSNavigation(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableGPSNavigation(model_id);
	}

	// interior
	@GetMapping("api/bt/{model_id}")
	public List<SubCompPrice> getConfigurableBlueTooth(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableClimateControl(model_id);
	}

	@GetMapping("api/info/{model_id}")
	public List<SubCompPrice> getConfigurableInfoSys(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableInfoSys(model_id);
	}

	@GetMapping("api/climatecontrol/{model_id}")
	public List<SubCompPrice> getConfigurableClimateControl(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableClimateControl(model_id);
	}

	// exterior
	@GetMapping("api/alloy/{model_id}")
	public List<SubCompPrice> getConfigurableAlloy(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableAlloy(model_id);
	}

	@GetMapping("api/led/{model_id}")
	public List<SubCompPrice> getConfigurableLED(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableLED(model_id);
	}

	@GetMapping("api/parkingsensor/{model_id}")
	public List<SubCompPrice> getConfigurableParkingSensor(int model_id) {
		// TODO Auto-generated method stub
		return alt_mgr.getConfigurableParkingSensor(model_id);
	}

}
