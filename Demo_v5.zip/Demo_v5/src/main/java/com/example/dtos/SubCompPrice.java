package com.example.dtos;

public class SubCompPrice {
	
	private String Sub_type;
	
	private double delta_price;
	
	

	public SubCompPrice(String sub_type, double price) {
		super();
		Sub_type = sub_type;
		this.delta_price = price;
	}

	public String getSub_type() {
		return Sub_type;
	}

	public void setSub_type(String sub_type) {
		Sub_type = sub_type;
	}

	public double getPrice() {
		return delta_price;
	}

	public void setPrice(int price) {
		this.delta_price = price;
	}
	
	
	
	

}
