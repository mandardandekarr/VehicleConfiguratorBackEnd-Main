package com.example.services;

import java.util.List;

import com.example.entities.Variant;

public interface Variantmanager {
	List<Variant> getvariant(int seg_id , int mfg_id);
	
}
