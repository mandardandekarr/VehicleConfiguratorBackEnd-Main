package com.example.services;

import java.util.List;

public interface VehicleDetailManager {

	public List<String>  getVehicleDetailsByCore(int model_id);
	public List<String> getVehicleDetailsByStandard(int model_id);
	public List<String>  getVehicleDetailsByInterior(int model_id);
	public List<String>  getVehicleDetailsByExterior(int model_id);
	public double getPrice(int model_id);
	/*
	List<String> getCompname(int model_id);
	List<String> getSubType(int model_id);
	*/
}
