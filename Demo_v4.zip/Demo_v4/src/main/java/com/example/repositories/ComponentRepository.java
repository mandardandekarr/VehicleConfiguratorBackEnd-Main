package com.example.repositories;


import org.springframework.stereotype.Repository;


import jakarta.transaction.Transactional;


@Repository
@Transactional
public class ComponentRepository  {

}
